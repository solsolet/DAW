<?php
    $lista = 1;
    include "inc/cabecera.php"
?>  
    <section>                
        <h2>¡Aviso!</h2>
        <p class="aviso"><b>Error 404</b> - Página no encontrada</p>
    </section> 
       
    <?php
    include "inc/footer.php"
?>