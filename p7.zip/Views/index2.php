<?php
    $lista = 2;
    include "inc/cabecera.php"
?>  
    <section>
        <h2>Las últimas fotos</h2>
        <div class="image-grid">
            <!-- En la práctica usad cinco imágenes diferentes, no repetir la misma -->
            <article class="carta"><a href="foto.php"><img src="imagenes/rashito.jpeg" alt="El Rasho Macuin FIAUUUUUUUUU"></a>
                <h3>Rayo Mqueen</h3>
                <p>01-11-2020</p>
                <p>EEUU</p>
            </article>
            <article class="carta"><a href="foto.php"><img src="imagenes/Mate_-_Cars_2.webp" alt="EL MATE FIAUUUUUUUUU"></a>
                <h3>Mate</h3>
                <p>04-12-1999</p>
                <p>EEUU</p>    
            </article>
            <article class="carta"><a href="foto.php"><img src="imagenes/sally.jpg" alt="LA SALLY FIAUUUUUUUUUU"></a>
                <h3>Sally</h3>
                <p>21-12-2021</p>
                <p>EEUU</p>
            </article>                       
            <article class="carta"><a href="foto.php"><img src="imagenes/copapiston.jpg" alt="LA COPA PISTÓN FIAUUUUUUUUU"></a>
                <h3>Copa Pistón</h3>
                <p>31-02-2007</p>
                <p>Internacional</p>
            </article>
            <article class="carta"><a href="foto.php"><img src="imagenes/francesco.jpg" alt="La Maquina Mas Blos, de TOTE ITALE FIAUUUUU"></a>
                <h3>Francesco Virgolini</h3>
                <p>08-04-2014</p>
                <p>Italia</p>
            </article>
        </div>
    </section>
    
    <?php
    include "inc/footer.php"
?>