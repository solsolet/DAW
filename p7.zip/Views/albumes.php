<?php
    $lista = 2;
    include "inc/cabecera.php"
?>  

    <section>
        <h2>Álbumes</h2>
        <p class = "aviso">(información)</p>
    </section>
    
    <?php
    include "inc/footer.php"
?>