<?php
    $lista = 2;
    include "inc/cabecera.php"
?> 
    <section>
        <h2>Datos</h2>
        <p>(información)</p>
    </section>
    
    <?php
    include "inc/footer.php"
?>