<?php

abstract Class Model {
    protected function insertData($table) {
          }
          protected function saveData($table) {
          }
  }
  
?>